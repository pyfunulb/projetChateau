import turtle

""" Jeu d'apprentissage de la programmation
Thierry Massart, Jean Olgiati, été 2020
"""
# Désignation des fichiers de données à utiliser
fichier_plan = '../../../plan_chateau.txt'
fichier_portes = '../../../dico_portes.txt'
fichier_objets = '../../../dico_objets.txt'
POSITION_DEPART = [0, 1]  # Porte d'entrée du château
# Les 4 valeurs ci-dessous sont calculées pour une définition d'écran minimum de 1024 x 768,
# donnant une fenêtre Turtle de 512 x 576 pixels.
ZONE_PLAN_MINI = (-240, -240)  # Coin inférieur gauche de la zone d'affichage du plan dans la fenêtre Turtle
ZONE_PLAN_MAXI = (50, 200)  # Coin supérieur droit de la zone d'affichage du plan dans la fenêtre Turtle
POINT_AFFICHAGE_ANNONCES = (-240, 240)  # Point d'origine de l'affichage des annonces
POINT_AFFICHAGE_INVENTAIRE = (70, 210)  # Point d'origine de l'affichage de l'inventaire
# Les valeurs ci-dessous définissent les couleurs des cases du plan
COULEUR_CONTOURS = 'white'
COULEUR_COULOIR = 'white'
COULEUR_MUR = 'grey'
COULEUR_OBJECTIF = 'yellow'
COULEUR_PORTE = 'orange'
COULEUR_OBJET = 'green'
COULEUR_VUE = 'wheat'
COULEURS = [COULEUR_COULOIR, COULEUR_MUR, COULEUR_OBJECTIF, COULEUR_PORTE, COULEUR_OBJET, COULEUR_VUE]
COULEUR_EXTERIEUR = 'white'
# Valeurs liées au personnage
COULEUR_PERSONNAGE = 'red'
RATIO_PERSONNAGE = 0.9  # Rapport entre diamètre du personnage et dimension des cases


# Fonctions d'acquisition et de tracé du plan
def lire_matrice(fichier):
    """ Fonction créant la matrice du plan depuis un fichier donné en argument, dans lequel les cases sont
    représentées par des chiffres organisés en lignes et colonnes, séparés par des espaces
    """
    with open(fichier, encoding='utf-8') as fichier_in:
        matrice = [[int(valeur) for valeur in ligne.split()] for ligne in fichier_in]
    return matrice


def lire_dico(fichier):
    """ Fonction créant un dictionnaire depuis un fichier donné en argument.
    Chaque ligne du fichier doit contenir une clef et une valeur, séparées une virgule et un espace.
    """
    with open(fichier, encoding='utf-8') as fichier_in:
        clefs = []
        valeurs = []
        for ligne in fichier_in:
            clefs.append(eval(ligne)[0])
            valeurs.append(eval(ligne)[1])
    return dict(zip(clefs, valeurs))


def calculer_pas(matrice):
    """ Fonction calculant la dimension en pixels des cases pour faire entrer dans la zone prévue
    le plan dont la matrice est donnée en argument.
    """
    pas_x = (ZONE_PLAN_MAXI[0] - ZONE_PLAN_MINI[0]) / len(matrice[0])
    pas_y = (ZONE_PLAN_MAXI[1] - ZONE_PLAN_MINI[1]) / len(matrice)
    pas = min(pas_x, pas_y)
    return pas


def coordonnees(case, pas):
    """ Fonction renvoyant le couple des coordonnées en pixels d'une case donnée en premier argument (sous forme
    d'un couple de colonne et ligne) et d'une dimension donnée en second argument.
    """
    x = ZONE_PLAN_MINI[0] + case[1] * pas
    y = ZONE_PLAN_MAXI[1] - case[0] * pas  # Quand le numéro de ligne augmente, l'ordonnée diminue.
    return x, y


def tracer_carre(pas):
    """ Fonction traçant un carré centré sur la tortue, dont la dimension est donnée en argument. """
    turtle.setheading(0)  # réorienter la tortue vers la droite
    turtle.begin_fill()
    for i in range(4):
        turtle.forward(pas)
        turtle.left(90)
    turtle.end_fill()


def tracer_case(case, nature, pas):
    """ Fonction traçant une case du plan, recevant en arguments la case (couple de numéros de colonne et de ligne),
    sa nature et sa dimension """
    turtle.up()
    turtle.goto(coordonnees(case, pas))
    turtle.down()
    turtle.color(COULEUR_CONTOURS, COULEURS[nature])
    tracer_carre(pas)


def lire_nature(matrice, case):
    """ Fonction allant lire la nature d'une case dans la matrice représentant un plan.
    L'argument case est un couple (numéro de colonne, numéro de ligne).
    """
    return matrice[case[0]][case[1]]  # T


def afficher_plan(matrice):
    """ Fonction dessinant le plan contenu dans une matrice (séquence de séquences) passée en argument.
    """
    for ligne in range(len(matrice)):
        for colonne in range(len(matrice[0])):
            case = (ligne, colonne)  # T ligne <-> colonne
            tracer_case(case, lire_nature(matrice, case), mon_pas)


# Fonctions de gestion du déplacement
def deplacer_gauche():
    turtle.onkeypress(None, "Left")
    deplacer(matrice_plan, ma_position, (0, -1), mon_inventaire)  # T -1 <-> 0
    turtle.onkeypress(deplacer_gauche, "Left")


def deplacer_droite():
    turtle.onkeypress(None, "Right")
    deplacer(matrice_plan, ma_position, (0, 1), mon_inventaire)  # T 1 <-> 0
    turtle.onkeypress(deplacer_droite, "Right")


def deplacer_haut():
    turtle.onkeypress(None, "Up")
    deplacer(matrice_plan, ma_position, (-1, 0), mon_inventaire)  # T -1 <-> 0
    turtle.onkeypress(deplacer_haut, "Up")


def deplacer_bas():
    turtle.onkeypress(None, "Down")
    deplacer(matrice_plan, ma_position, (1, 0), mon_inventaire)  # T -1 <-> 0
    turtle.onkeypress(deplacer_bas, "Down")


def deplacer(matrice, position, mouvement, inventaire):
    """ Fonction examinant ce que produit la tentative de déplacement souhaitée par le joueur :
        - argument mouvement : couple indiquant la direction du déplacement souhaité """
    destination = (position[0] + mouvement[0], position[1] + mouvement[1])
    if test_limites_plan(destination):
        nature = lire_nature(matrice, destination)
        if nature == 1:
            mouvement = (0, 0)
        elif nature == 2:
            afficher_victoire()
        elif nature == 3:
            mouvement = poser_question(matrice, destination, mouvement)
        elif nature == 4:
            ramasser_objet(destination, inventaire)
        noter_case_vue(matrice, position)
        deplacer_personnage(position, mouvement)
        return position


def test_limites_plan(case):
    """ Fonction testant si la case passée en argument est dans les limites du plan """
    return 0 <= case[0] < len(matrice_plan) and 0 <= case[1] < len(matrice_plan[0])


def noter_case_vue(matrice, case):
    """ Fonction enregistrant et affichant qu'une case a été visitée"""
    matrice[case[0]][case[1]] = 5  # T 0<-> 1
    tracer_case(case, 5, mon_pas)


def deplacer_personnage(case, mouvement):
    """ Fonction pour ôter le personnage d'une case et l'afficher sur sa nouvelle case """
    tracer_case(case, lire_nature(matrice_plan, case), mon_pas)  # Effacer la position actuelle
    case[0] += mouvement[0]
    case[1] += mouvement[1]
    placer_personnage(case)


def placer_personnage(case):
    turtle.up()
    turtle.goto(coordonnees(case, mon_pas))
    turtle.setheading(0)
    turtle.forward(mon_pas / 2)
    turtle.left(90)
    turtle.forward(mon_pas / 2)
    turtle.dot(int(RATIO_PERSONNAGE * mon_pas), COULEUR_PERSONNAGE)


def poser_question(matrice, case, mouvement):
    """ Fonction d'affichage de la question et saisie de la réponse si le personnage veut franchir une porte fermée """
    afficher_annonce('Cette porte est fermée.')
    reponse = turtle.textinput("Question", dico_portes[case][0])
    turtle.listen()  # On relance l'écoute du clavier interrompue par le "textinput" de la ligne précédente
    if reponse == dico_portes[case][1]:
        matrice[case[0]][case[1]] = 0  # T 0<->1 On ouvre la porte dans la matrice...
        tracer_case(case, lire_nature(matrice, case), mon_pas)  # ... et sur le plan affiché
        afficher_annonce("La porte s'ouvre !")
    else:
        afficher_annonce('Mauvaise réponse')
        mouvement = (0, 0)
    return mouvement


def ramasser_objet(case, inventaire):
    """ Fonction affichant l'objet si le personnage se trouve sur une case objet"""
    afficher_annonce('Vous avez trouvé un objet : ' + dico_objets[tuple(case)])
    matrice_plan[case[0]][case[1]] = 5  # T 0<->1  L'objet est ramassé, donc la case est notée comme vue
    inventaire.append(dico_objets[tuple(case)])
    afficher_inventaire(case, inventaire)
    tracer_case(case, lire_nature(matrice_plan, case), mon_pas)


# Fonctions de gestion du texte
def effacer_annonce():
    turtle.up()
    turtle.goto(POINT_AFFICHAGE_ANNONCES)
    turtle.setheading(0)
    turtle.color(COULEUR_EXTERIEUR)
    turtle.begin_fill()
    for i in range(2):
        turtle.forward(512)
        turtle.left(90)
        turtle.forward(30)
        turtle.left(90)
    turtle.end_fill()


def afficher_annonce(annonce):
    effacer_annonce()
    turtle.goto(POINT_AFFICHAGE_ANNONCES)
    turtle.color('black')
    turtle.write(annonce, font=("Arial", 12, "bold"))


def afficher_victoire():
    """ Fonction affichant Bravo si le joueur entre sur la case finale """
    effacer_annonce()
    turtle.goto(POINT_AFFICHAGE_ANNONCES)
    turtle.color('black')
    turtle.write("Bravo ! Vous avez gagné.", font=("Arial", 20, "bold"))


def afficher_inventaire(case, inventaire):
    """ Fonction affichant le nouvel objet à la suite de l'inventaire """
    nouvelle_ligne = (POINT_AFFICHAGE_INVENTAIRE[0], POINT_AFFICHAGE_INVENTAIRE[1] - 20 * len(inventaire))
    turtle.goto(nouvelle_ligne)
    turtle.write('N°' + str(len(inventaire)) + ' : ' + dico_objets[tuple(case)], font=("Arial", 8, "bold"))


# Lecture des fichiers de données
matrice_plan = lire_matrice(fichier_plan)
# print(matrice_plan) #T debug
dico_portes = lire_dico(fichier_portes)
# print(dico_portes) #debug
dico_objets = lire_dico(fichier_objets)
# print(dico_objets) # debug
# Tracé du château
turtle.tracer(0)
mon_pas = calculer_pas(matrice_plan)
afficher_plan(matrice_plan)
# Initialisation du personnage
ma_position = POSITION_DEPART
placer_personnage(ma_position)
# Initialisation de l'inventaire
mon_inventaire = []
turtle.goto(POINT_AFFICHAGE_INVENTAIRE)
turtle.color('black')
turtle.write('Inventaire :', font=("Arial", 10, "bold"))
# Démarrage du jeu
afficher_annonce("Vous devez mener le point rouge jusqu'à la sortie jaune.")
turtle.listen()  # Déclenche l'écoute du clavier
turtle.onkeypress(deplacer_gauche, "Left")  # Associe à la touche Left une fonction appelée fleche_gauche
turtle.onkeypress(deplacer_droite, "Right")
turtle.onkeypress(deplacer_haut, "Up")
turtle.onkeypress(deplacer_bas, "Down")
turtle.mainloop()  # Place le programme en position d'attente d'une action du joueur
